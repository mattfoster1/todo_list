/* Plan:
- Backend / database
- Typing area (CMS)
	- 'add' button
	- Delete item (item by item)
		- need to be able to check it off
	- Rename/edit item
	- 'Done' option on items
		- Will be struckthrough
- Sorting options
- Archive
- "Done" option

- Data to be fed from JS to DOM by a series of arrays. 
	- Each array will include the formatting to put it on a new line

*/


var serialNo = 0; //keeps track of each Todo
var topSerialNo = 0; //keeps track of total number of serial numbers in use
var btnAddJS;
var retrievedObject;
var mainTodoArray = [1];
var maxSerialNo = localStorage.getItem("maxSerialNo"); //TASK - this needs to be called from localStorage each time
console.log("maxSerialNo = " + maxSerialNo);
var dataInObject = {}
var data1 = {}//temp contains objects 
var data2 = {}
var todo1 = "";


var start = function() {
	console.log("         NOTICE: start() function triggered");

	// setup for 'new Todo' button
	var btnAddJS = document.getElementById("btnadd");
	maxSerialNo = localStorage.getItem("maxSerialNo");
	console.log("maxSerialNo = " + maxSerialNo);
	console.dir(localStorage);
	
	
		
	if ((typeof maxSerialNo == "undefined") || (maxSerialNo === null)) {
		maxSerialNo = 0;
		// info1 = "Placeholder 111 - start()";
		// incrementMaxSerialNo();
		console.log("thingy");
		// console.log(localStorage.getItem("maxSerialNo"));
	} else {
		console.log("proceeding");
		retrieveAllData();
		displayNewTodo(); //NB this is also triggered in retrieveAllData(); it loops fine for now but might cause issues down the road
	};
	
    
 //    if(typeof JSON.parse(localStorage.getItem(serialNo)) === "undefined") {
	// 	info1 = "Placeholder 111 - start()";
	// 	console.log("info1 = " + info1);
	// };
	
};

var store = function() { //triggers when clicking custom store button
	var d = new Date();
	//Pull content from input fields (DOM)
	console.log("           NOTICE: store(); triggered");
    var formToStore1 = document.getElementById("formcontent1");
    var formToStore2 = document.getElementById("formcontent2");
    var formToStore3 = document.getElementById("formcontent3");
    var formToStore4 = document.getElementById("priority");
    var formToStore5 = d.getTime();
    // console.log("formToStore1,2,3 = " + formToStore1.value  + ", " + formToStore2.value + ", " + formToStore3.value);

    if (formToStore1.value === "") {
    	formToStore1.value = "Invalid Entry";
    };

    //Build an object (to be stringified)
    data1 = {
    	name: maxSerialNo,
    	info1: formToStore1.value, 
    	info2: formToStore2.value, 
    	info3: formToStore3.value,
    	Priority: formToStore4.value, 
    	Timestamp: formToStore5,
    };

    //Stringify and store
    var x = JSON.stringify(data1);
    localStorage.setItem("stringData" + maxSerialNo, x);
    
    incrementMaxSerialNo();
    	// storeMaxSerialNo();

    retrieveAllData();
};



//retrieve data, put into array
var retrieveAllData = function() {
	console.log("        NOTICE: retrieveAllData(); triggered");
	console.log("--------------------------------------")
	mainTodoArray = [];
	todo1 = "";
	console.log("maxSerialNo = " + maxSerialNo);

	//pulls info from localStorage
	for (s = 0; s < maxSerialNo; s++) { //will this work without defining a variable? surely === should become =
		
		//Retrieve string and parse (make an object again)
		var parsedData = JSON.parse(localStorage.getItem("stringData" + s));//this should be fed into the main array
		// console.log(parsedData);
		
		//push all objects to mainTodoArray
		mainTodoArray.push(parsedData);


		var content = mainTodoArray[s]["info1"];
    	todo1 = "<input type=\"checkbox\"/>" + content; //TASK: this needs to be changed to give each Todo a div of its own. There isn't enough control as it is.
    	console.log("______" + "loop" + s + "______");    	

    	document.getElementById("slot" + s).innerHTML = todo1;
		
    	// var content = mainTodoArray[s]["info1"];
    	// todo1 += "<br>" + "<input type=\"checkbox\"/>" + content; //TASK: this needs to be changed to give each Todo a div of its own. There isn't enough control as it is.
    	// console.log("______" + "loop" + s + "______");    	
	};

    console.log("maxSerialNo = " + maxSerialNo);
    // console.log(todo1);
	console.dir(mainTodoArray);	
	displayNewTodo();
};

var displayNewTodo = function() {
	console.log("       NOTICE: displayNewTodo(); triggered");
		// console.log("todo1 = " + todo1)
		document.getElementById("todolist").innerHTML = todo1;
	// };
};

var resetData = function() {
	console.log("resetData");
	maxSerialNo = 0;
	localStorage.setItem("maxSerialNo", maxSerialNo);
	localStorage.clear();
	location.reload();
};

var incrementMaxSerialNo = function() {
	maxSerialNo++;
	console.log("maxSerialNo = " + maxSerialNo);
	console.log("       NOTICE: incrementMaxSerialNo triggered (to " + maxSerialNo + ")");
	localStorage.setItem('maxSerialNo', maxSerialNo);
	console.dir(localStorage);
};

var storeMaxSerialNo = function() {
	localStorage.setItem('maxSerialNo', maxSerialNo);
}

// var makeTodoExperiment = function() {

// 	var item1 = {priority: "normal", content: "Write this Checklist", urgency: "high", category: "main"};
// 	console.log("item1 = " + item1);

// 	var storedItems = JSON.stringify(item1);
// 	console.log("storedItems = " + storedItems);

// 	window.localStorage.setItem('storedItems', storedItems);

// 	var retrievedObject = localStorage.getItem('storedItems');
// 	console.log("retrievedObject1 = " + retrievedObject1);

// 	var finished = JSON.parse(retrievedObject1);
// 	console.log('finished = vv');
// 	console.log(finished);

// };



// var lukesCrap = function() {

// 	var makeTodoItem = function(title, completed, timestamp) {
// 		return {
// 			timestamp: timestamp || Date.now(),
// 			title:title ||'',
// 			completed: !!completed
// 		};
// 	}

// 	//Make a Todo item
// 	sessionItems.push(makeTodoItem('Fix washing machine'));

// 	//Store the Todo Items
// 	window.localStorage.setString('todoItems',JSON.stringify(sessionItems));

// 	//Fetch previous session data (if any).
// 	var storedItems = window.localStorage.getString( 'todoItems'),
// 		sessionItems = null;

// 	if (storedItems){
// 		sessionItems = JSON.parse(storedItems);
// 	}
// 	else {
// 		sessionItems = [];
// 	}

// };


