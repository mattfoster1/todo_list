/* Plan:
- Backend / database
- Typing area (CMS)
	- 'add' button
	- Delete item (item by item)
		- need to be able to check it off
	- Rename/edit item
	- 'Done' option on items
		- Will be struckthrough
- Sorting options
- Archive
- "Done" option

- Data to be fed from JS to DOM by a series of arrays. 
	- Each array will include the formatting to put it on a new line

*/


var serialNo = 0; //keeps track of each Todo
var topSerialNo = 0; //keeps track of total number of serial numbers in use
var btnAddJS;
var retrievedObject;
// var additionalFormatting = "<br>" + maxSerialNo.value
var mainTodoArray = [];
var maxSerialNo; //TASK - this needs to be called from localstorage each time
var dataInObject = {}
var data1 = {}//temp contains objects 
var data2 = {}
var todo1 = "kdjnkjnkjn";

var start = function() {
	console.log("NOTICE: start() function triggered");
	var btnAddJS = document.getElementById("btnadd");// setup for 'new Todo' button
	maxSerialNo = localStorage.getItem("maxSerialNo");
	console.log("maxSerialNo = " + maxSerialNo);
	if(maxSerialNo === undefined) {
		maxSerialNo = 0;
		storeMaxSerialNo();
		// console.log(localStorage.getItem("maxSerialNo"));
	};
    // retrieveAllData();
};

var store = function() { //triggers when clicking custom store button
	
	//Pull content from input fields (DOM)
	console.log("FUNCTION: store(); triggered");
    var formToStore1 = document.getElementById("formcontent1");
    var formToStore2 = document.getElementById("formcontent2");
    var formToStore3 = document.getElementById("formcontent3");
    // console.log("formToStore1,2,3 = " + formToStore1.value  + ", " + formToStore2.value + ", " + formToStore3.value);

    if (formToStore1.value === "") {
    	formToStore1.value = "Invalid Entry";
    };

    //Build an object (to be stringified)
    data1 = {
    	name: maxSerialNo,
    	info1: formToStore1.value, 
    	info2: formToStore2.value, 
    	info3: formToStore3.value, 
    	bum: "fun"
    };
    // data2 = {bum: "fun", ears: "not"}
    // console.log("data = " + data1.info1 + ", " + data1.info2 + ", " + data1.info3);

    //Stringify and store
    var x = JSON.stringify(data1);
    localStorage.setItem("stringData" + maxSerialNo, x);

    retrieveAllData();
    // location.reload();   	
};



//retrieve data
var retrieveAllData = function() {
	console.log("FUNCTION: retrieveAllData(); triggered");
	
	//pulls info from localStorage
	for (serialNo=0; serialNo <= maxSerialNo; serialNo++) {
		
		//Retrieve string and parse (make an object again)
		var parsedData = JSON.parse(localStorage.getItem("stringData" + serialNo));//this should be fed into the main array
		
		//push all objects to mainTodoArray
		mainTodoArray.push(parsedData);//possibly this is failing

		// pull data from object
    	
		var z = mainTodoArray[serialNo];
		console.log(z.info1);
    	todo1 += "<li>" + z.info1 + "<br></li>";
    	console.log("loop");
	};
	

    // console.log(mainTodoArray.length);
    // console.log(mainTodoArray[1]);
    // console.log(mainTodoArray[2, data1.info1]);
    // console.log(data1.info1);

    maxSerialNo++;
    console.log("maxSerialNo Incremented");
    storeMaxSerialNo();
    console.log(todo1);
	
	displayNewTodo();
    
    console.log(document.getElementById("todolist").innerHTML);
};

var displayNewTodo = function() {
	console.log("FUNCTION: displayNewTodo(); triggered");
	// if (document.getElementById("todolist").innerHTML = "kdjnkjnkjn") {
	// 		alert("hi");
	//	 } else {
			document.getElementById("todolist").innerHTML = todo1; //this is happening too early, before value can be changed
	// };
};

var resetData = function() {
	console.log("resetData");
	maxSerialNo = 0;
	localStorage.setItem("maxSerialNo", maxSerialNo);
	location.reload();
};

var storeMaxSerialNo = function() {
localStorage.setItem('maxSerialNo', maxSerialNo);
};



// var makeTodoExperiment = function() {

// 	var item1 = {priority: "normal", content: "Write this Checklist", urgency: "high", category: "main"};
// 	console.log("item1 = " + item1);

// 	var storedItems = JSON.stringify(item1);
// 	console.log("storedItems = " + storedItems);

// 	window.localStorage.setItem('storedItems', storedItems);

// 	var retrievedObject = localStorage.getItem('storedItems');
// 	console.log("retrievedObject1 = " + retrievedObject1);

// 	var finished = JSON.parse(retrievedObject1);
// 	console.log('finished = vv');
// 	console.log(finished);

// };



// var lukesCrap = function() {

// 	var makeTodoItem = function(title, completed, timestamp) {
// 		return {
// 			timestamp: timestamp || Date.now(),
// 			title:title ||'',
// 			completed: !!completed
// 		};
// 	}

// 	//Make a Todo item
// 	sessionItems.push(makeTodoItem('Fix washing machine'));

// 	//Store the Todo Items
// 	window.localStorage.setString('todoItems',JSON.stringify(sessionItems));

// 	//Fetch previous session data (if any).
// 	var storedItems = window.localStorage.getString( 'todoItems'),
// 		sessionItems = null;

// 	if (storedItems){
// 		sessionItems = JSON.parse(storedItems);
// 	}
// 	else {
// 		sessionItems = [];
// 	}

// };


