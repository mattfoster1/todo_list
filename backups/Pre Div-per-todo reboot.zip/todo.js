/* Plan:
- Backend / database
- Typing area (CMS)
	- 'add' button
	- Delete item (item by item)
		- need to be able to check it off
	- Rename/edit item
	- 'Done' option on items
		- Will be struckthrough
- Sorting options
- Archive
- "Done" option

- Data to be fed from JS to DOM by a series of arrays. 
	- Each array will include the formatting to put it on a new line

*/


var serialNo = 0; //keeps track of each Todo
var topSerialNo = 0; //keeps track of total number of serial numbers in use
var btnAddJS;
var retrievedObject;
var mainTodoArray = [1];
var maxSerialNo = localStorage.getItem("maxSerialNo"); //TASK - this needs to be called from localStorage each time
console.log("maxSerialNo = " + maxSerialNo);
var dataInObject = {}
var data1 = {}//temp contains objects 
var data2 = {}
var todo1 = "";
var t;


var start = function() {
	console.log("         NOTICE: start() function triggered");
	jsCheck();

		// setup for 'new Todo' button
	var btnAddJS = document.getElementById("btnadd");
	maxSerialNo = localStorage.getItem("maxSerialNo");
	console.log("maxSerialNo = " + maxSerialNo);
	console.dir(localStorage);
	
	
		
	if ((typeof maxSerialNo == "undefined") || (maxSerialNo === null)) {
		maxSerialNo = 0;
	} else {
		retrieveAllData();
	};
	
 	// if(typeof JSON.parse(localStorage.getItem(serialNo)) === "undefined") {
	// info1 = "Placeholder 111 - start()";
	// console.log("info1 = " + info1);
	// };
};




var store = function() { //triggers when clicking custom store button
	var d = new Date();
	//Pull content from input fields (DOM)
	console.log("           NOTICE: store(); triggered");
    var formToStore1 = document.getElementById("formcontent1");
    var formToStore2 = document.getElementById("formcontent2");
    var formToStore3 = document.getElementById("formcontent3");
    var formToStore4 = document.getElementById("priority");
    var formToStore5 = d.getTime();
    // console.log("formToStore1,2,3 = " + formToStore1.value  + ", " + formToStore2.value + ", " + formToStore3.value);

    if (formToStore1.value === "") {
    	formToStore1.value = "Invalid Entry";
    };

    //Build an object (to be stringified)
    data1 = {
    	name: maxSerialNo,
    	info1: formToStore1.value, 
    	info2: formToStore2.value, 
    	info3: formToStore3.value,
    	Priority: formToStore4.value, 
    	Timestamp: formToStore5,
    	State: 0,
    };

    //Stringify and store
    var x = JSON.stringify(data1);
    localStorage.setItem("stringData" + maxSerialNo, x);
    
    incrementMaxSerialNo();
    	// storeMaxSerialNo();

    retrieveAllData();
};



	//retrieve data, put into array
var retrieveAllData = function() {
	// console.log("        NOTICE: retrieveAllData(); triggered");
	console.log("--------------------------------------")
	mainTodoArray = [];
	todo1 = "";
	console.log("maxSerialNo = " + maxSerialNo);

		//Clears out last load of data, otherwise it duplicates
	document.getElementById("todolist").innerHTML = null;

		//pulls info from localStorage, then push it to divs in .html page
	for (s = 0; s < maxSerialNo; s++) { //will this work without defining a variable? surely === should become =
		
		t = JSON.stringify(s);

			//Retrieve string and parse (make an object again)
		var parsedData = JSON.parse(localStorage.getItem("stringData" + s));//this should be fed into the main array
		// console.log(parsedData);
		
			//push all objects to mainTodoArray
		mainTodoArray.push(parsedData);

			//pulls appropriate content out of array
		var content = mainTodoArray[s]["info1"];
    	
    		//sets up div
    	todo1 = content;
    	console.log("______" + "loop" + s + "______");  

    	var node1 = document.createElement("todolist" + t);
		var element = document.getElementById("todolist");  	
    	
    		//Forms nodes (non-visual) putting todo1 (var) inside node1 (node)
    	var node2 = document.createTextNode(todo1);
    	node1.appendChild(node2);
    	
    		//Adds content to the new node, puts it on a new line
		element.appendChild(node1);
		document.getElementById("todolist").lastChild.innerHTML += "<br>";
		// document.getElementById("todolist").lastChild.setAttribute("id", "lineNo" + s);
		document.getElementById("todolist").lastChild.id =  "lineNo" + t;
		document.getElementById("todolist").lastChild.setAttribute("onclick", "killLine()");
		document.getElementById("todolist").lastChild.className = "points";

		// console.log(t + ", " + mainTodoArray[s]["name"]);

		
	};
console.dir(document.getElementById("todolist").childNodes);


};

var killLine = function() {
	// console.log(document.getElementById("lineNo1").innerHTML);
	console.log();
	// document.getElementById("lineNo1").setAttribute("color", "blue");
};

var resetData = function() {
	// console.log("resetData");
	maxSerialNo = 0;
	localStorage.setItem("maxSerialNo", maxSerialNo);
	localStorage.clear();
	location.reload();
};

var incrementMaxSerialNo = function() {
	maxSerialNo++;
	console.log("maxSerialNo = " + maxSerialNo);
	console.log("       NOTICE: incrementMaxSerialNo triggered (to " + maxSerialNo + ")");
	localStorage.setItem('maxSerialNo', maxSerialNo);
	console.dir(localStorage);
};

var storeMaxSerialNo = function() {
	localStorage.setItem('maxSerialNo', maxSerialNo);
}

var jsCheck = function() {
	if (window.jQuery) {
		console.log("__jQuery Yes__");
	} else {
		console.log("- - jQuery No - -");
	}
}

// var lukesCrap = function() {<><>var makeTodoItem = function(title, completed, timestamp) {<><>return {<><>timestamp: timestamp || Date.now(),<><>title:title ||'',<><>completed: !!completed<><>};<><>}
